package modelo.mundo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {

static int select = -1; //opci�n elegida del usuario
	
	public static void main(String[] args) {
		
		
		
		
		Empleado empleado1= new Empleado();
		
		
		while (select  != 0) { //ciclo o bucle termina si digitamos "6"
			
		try {
			 //instaciaamos un objeto
			Scanner sc = new Scanner (System.in); //creamos un objeto de entrada de datos
			String nombreEmpleado = "";
			String apellidoEmpledo = "";
			int dia; 
			int anio;
			int mes;
			int genero = 0 ;
			double salario = 0;
			String imagen = "";
			Fecha fechaNacimiento;
			Fecha fechaIngreso;
			System.out.println("\t\tESPE\n\tMenu de Opciones: ");
			System.out.println("\t1. Registro");
			System.out.println("\t2. Calcular la edad del empleado");
			System.out.println("\t3. Calcular la antig�edad del empleado en la empresa");
			System.out.println("\t4. Calcular las prestaciones del empleado.");
			System.out.println("\t5. Visualizar la informaci�n del empleado");
			System.out.println("\t6. Salir\n");
			
			System.out.print("\n\tSu opcion es: ");
			select = sc.nextInt(); 
			switch (select) {
			case 1: 
				System.out.println("\n\nDIGITE LOS DATOS DEL EMPLEADO:");
				
				//validar primer nombre
				do { 
					try {
				
				System.out.println("Primer Nombre: ");
				nombreEmpleado = sc.next();
				} catch ( Exception  e) {
					System.out.println("Digite de nuevo el nombre");
					nombreEmpleado = "";
				}
				} while (!nombreEmpleado.matches("[a-zA-Z]*"));
				
				//validar apellido 
				do {
					try {
						System.out.println("Primer Apellido: ");
						apellidoEmpledo=sc.next();
					} catch(Exception e) {
						System.out.println("Digite de nuevo el nombre");
					}
				} while (!apellidoEmpledo.matches("[a-zA-Z]*"));
				
				//validar genero
		        do {
		        	try {
						System.out.println("Genero (1 para masculino, 2 para femenino): ");
						genero= sc.nextInt();
									
					}
					catch(InputMismatchException e) {
						System.out.println("Debe ingresar solo n�meros ");
						genero = 0;
						sc.nextLine();
					}
		        }while (genero<1 || genero>2);
		       
		        //validar salario
		        do {
				try {
					System.out.println("Salario: ");
			        salario = sc.nextDouble();
				}
				catch(InputMismatchException e) {
					System.out.println("Debe ingresar solo n�meros tipo double ");
					salario = 0;
					e.printStackTrace();
				}
				}while (salario > 0.00 && salario <10.000 ); //es la cantidad maxima que se puede retirar en ecuador 
				
				//validacion de dia de nacimiento
				do {
					try {
						System.out.println("Ingrese dia de nacimiento (00): ");
				         dia = sc.nextInt();
					} catch (InputMismatchException e) {
						System.out.println("Debe ingresar dias validos");
					    dia = 0; 
					    e.printStackTrace();
					}
					} while (dia >0 && dia <=31);
				
				//validacion de mes de nacimiento
					do {
						try { 
							System.out.println("Ingrese mes de nacimiento (00): ");
					        mes = sc.nextInt();
						}catch (InputMismatchException e) {
							System.out.println("Debe ingresar dias validos");
							mes = 00; 
							e.printStackTrace();
						}
					}while (mes >00 || mes <=12);
		        
				//validar anio de nacimiento
					do {
						try {
							System.out.println("Ingrese a�o de nacimiento (0000): ");
					        anio = sc.nextInt();
						}catch (InputMismatchException e)
						{
							System.out.println("Debe ingresar anio validos");
							anio = 0000;
							e.printStackTrace();
						} 
					}while (anio >=1800 || anio <=2022);
		        
				
		        
		        fechaNacimiento = new Fecha(dia, mes, anio);
		        
		        do {
					try {
						System.out.println("Ingrese dia de ingreso (00): ");
				        dia = sc.nextInt();
					} catch (InputMismatchException e) {
						System.out.println("Debe ingresar dias validos");
						dia = 0; 
						e.printStackTrace();
					}
					} while (dia >=0 || dia <=31);
				
				//validacion de mes de nacimiento
					do {
						try { 
							System.out.println("Ingrese mes de ingreso (00): ");
					        mes = sc.nextInt();
						}catch (InputMismatchException e) {
							System.out.println("Debe ingresar dias validos");
							mes = 00; 
							e.printStackTrace();
						}
					}while (mes >=00 ||  mes <=12);
		        
				//validar anio de nacimiento
					do {
						try {
							System.out.println("Ingrese a�o de ingreso (0000): ");
					        anio = sc.nextInt();
						}catch (InputMismatchException e)
						{
							System.out.println("Debe ingresar anio validos");
							anio = 0000;
							e.printStackTrace();
						} 
					}while (anio >=2000 &&  anio <=2022);
		        
		        
		        
		        fechaIngreso = new Fecha(dia, mes, anio);
		        empleado1.setEmpleado(nombreEmpleado, apellidoEmpledo, genero, imagen, salario, fechaNacimiento, fechaIngreso);
				System.out.println("Por favor, vuelva al registro\n\n");
				break;
			case 2: 
				System.out.println("EDAD DEL EMPLEADO: \n");
				empleado1.calcularEdad();
				
				break;
			case 3: 
				System.out.println("ANTIGUEDAD DEL EMPLEADO: \n");
				empleado1.calcularAntiguedad();
				break;
			case 4: 
				System.out.println("PRESTACIONES DEL EMPLEADO:\n");
				empleado1.calcularPrestaciones();
				break;
			case 5: 
				System.out.println("INFORMACION DEL EMPLEADO:\n");
				empleado1.mostrarInformaic�n();
				break;
			case 6: 
				System.out.println("Hasta la proxima");
				break;
			default:
				System.out.println("No ha escogido una opic�n correcta");
				break;
			}
			
		}
		catch (Exception e){
			System.out.println("\n\nVuelva a intentarlo");
			
		
		}
		
	}
}
}


