package modelo.mundo;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class Empleado {
	
	//Atributos
	private String nombreEmpleado;
	private String apellidoEmpleado;
	private int genero;//1 Femenino, 2 Masculino
	private String imagen;
	private double salario;
	private Fecha fechaNacimiento;
	private Fecha fechaIngreso;
	
	
	//Metodo Constructor 
	public Empleado() {
	nombreEmpleado = "";
	apellidoEmpleado = "";
	genero = 0 ;
	imagen = "";
	salario=0.0;
	}
	
	//Sobrecarga de constructor
	public Empleado(String pNombreEmpleado,String pApellidoEmpleado,int pGenero, String pImagen,double pSalario) {
	nombreEmpleado= pNombreEmpleado;
	apellidoEmpleado = pApellidoEmpleado;
	genero=pGenero;
    imagen=pImagen;
    salario=pSalario;
	}

	//metodos get y set, (Obtener y Establcer)
	public String getNombre() {
		return nombreEmpleado;
	}
	
	public String getApellido() {
		return apellidoEmpleado;
	}
	
	public int getGenero() {
		return genero;
	}
	
	public Fecha getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public Fecha getFechaIngreso() {
		return fechaIngreso;
	}
	
	public String getImagen() {
		return imagen;
	}
	
	public double getSalario() {
		return salario;
	}
	
	public Fecha getFechaActual() {
		GregorianCalendar gc =new GregorianCalendar();
		int dia = gc.get(Calendar.DAY_OF_MONTH);
		int mes= gc.get(Calendar.MONTH)+1;
		int anio = gc.get(Calendar.YEAR);
		
		Fecha fechaActual = new Fecha(dia, mes, anio);
		return fechaActual;
	}
	
	public void setEmpleado(String pNombreEmpleado,String pApellidoEmpleado,int pGenero, String pImagen,double pSalario, Fecha fechaNacimiento2, Fecha fechaIngreso2) {
		nombreEmpleado= pNombreEmpleado;
		apellidoEmpleado = pApellidoEmpleado;
		genero=pGenero;
	    imagen=pImagen;
	    salario=pSalario;
	}
	
	public void setSalario(double pSalario) {
		salario=pSalario;
	}
	
public int calcularAntiguedad() {
		
		int antiguedad=0;
	    antiguedad = fechaIngreso.darDiferenciaEnMeses( getFechaActual() ) / 12;
	    return antiguedad;
	}
	
	 public int calcularEdad( ){
		 	 
	        int edad = fechaNacimiento.darDiferenciaEnMeses( getFechaActual()) / 12;

	        return edad;
	    }

	public double calcularPrestaciones() {
		double prestaciones;
		prestaciones= (calcularAntiguedad() * getSalario())/12;
		return prestaciones; 
	}
	
	public void mostrarInformaic�n() {
		System.out.println("\t\tINFORMACION DEL EMPLEADO");
		System.out.println("Nombre: "+getNombre());
		System.out.println("Apellido: "+ getApellido());
		System.out.println("G�nero 1M 2F"+ getGenero());
		System.out.println("Fecha de Nacimiento: "+ getFechaNacimiento());
		System.out.println("Fecha de ingreso a la empresa: "+getFechaIngreso());
		System.out.println("Salario b�sico: "+getSalario());
		System.out.println("Prestaciones: "+calcularPrestaciones());
		System.out.println("Antiguedad: "+calcularAntiguedad()+" a�os.");
	}
	
	

}
