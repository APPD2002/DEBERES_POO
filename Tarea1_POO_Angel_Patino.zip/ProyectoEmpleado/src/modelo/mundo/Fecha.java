package modelo.mundo;

public class Fecha {
	//atributos privados
	private int dia;
	private int mes;
	private int anio;
	
	//Constructor con parametros enteros
	public Fecha (int pdia, int pMes, int pAnio) {
		 dia= pdia; //inicializamos
		 mes=pMes;
		 anio=pAnio;
	}
	
	//metodos getter y setter
	public int getDia() {
		return dia;
	}
	
	public int getMes() {
		return mes;
	}
	
	public int getAnio() {
		return anio;
	}
	
	//metodo de fecha 
	public int darDiferenciaEnMeses(Fecha pFecha) {
    int numeroMeses = 0;
    int difAnios = anio - pFecha.getAnio()-anio*12;
	int difMeses = mes - pFecha.getMes();
	
	if(mes<pFecha.getMes()) {
		difMeses=mes-pFecha.getMes()- mes;
	}
	
	int difDias = 0;
    if(mes < pFecha.getMes()) {
    	difDias= (pFecha.getDia()-dia)/30;
    }
    
    numeroMeses =difAnios+difMeses+difDias;
    
    return numeroMeses; //retorno del metodo "darDiferenciaEnMeses"
	}
	
	//Concatenamos dd/mm/aaaa
	public String toString() {
		return dia + "/" + mes +"/" +anio;
	}
}
